---
title: "Mehedi Keil"
date: 2019-09-10T13:51:25+06:00
draft: false
description: "this is meta description"
bg_image : "images/bg/cta-bg.jpg"
image : "images/teams/s-6.jpg"
designation : "Content Writer"
email : "Martin@mail.com"
type : "speaker"
social:
  # social site loop
  - icon : "tf-ion-social-facebook"
    link : "#"
  # social site loop
  - icon : "tf-ion-social-twitter"
    link : "#"
  # social site loop
  - icon : "tf-ion-social-linkedin"
    link : "#"

# professional skill
skill:
  # skill loop
  - title : "Course Correction"
    icon : "tf-ion-android-document"
    content : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at."
    
  # skill loop
  - title : "Execute the Decision"
    icon : "tf-ion-android-desktop"
    content : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at."
    
  # skill loop
  - title : "Planning the Moves"
    icon : "tf-ion-android-bulb"
    content : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at."
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.